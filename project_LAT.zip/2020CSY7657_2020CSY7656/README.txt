COL780 - Project
Submitted by
Shivangi Bithel
Sagar Sharma

Model submission google drive link
https://drive.google.com/drive/folders/1v1sViF_9NumBebJmZ9Ai3TZAC1H_L3ZX?usp=sharing

##BASELINE: vit_base_patch16_224
We have implemented LA-Transformers method as our baseline without modifying any hyperparameters and trained on the 62 class train dataset given to us. 

Results on 12 class validation set with BW-FT
Rank1	Rank5	Rank10	MAP
0.9285	1	1	0.89

Results on 12 class validation set without BW-FT
Rank1	Rank5	Rank10	MAP
0.8928	0.9285	0.9642	0.8662

We futher improved the baseline with some hyperparameter tuning suitable for our dataset(which was comparitively smaller than the MARKET-1501)

Results on 12 class validation set with BW-FT
Rank1	Rank5	Rank10	MAP
0.9642	0.9642	0.9642	0.9268

WE are proposing two improvements in our model after trying various possible backbone models which can replace vit_base_patch16_224

Tried models:
1. deit_base_distilled_patch16_224 with BW-FT

Results on 12 class validation set
Rank1	Rank5	Rank10	MAP
0.8571	0.9285	0.9285	0.7101

2. deit_base_patch16_224 with BW-FT

Results on 12 class validation set
Rank1	Rank5	Rank10	MAP
0.8214	0.8571	0.9285	0.6891

3. deit_base_patch16_224 without BW-FT

Results on 12 class validation set
Rank1	Rank5	Rank10	MAP
0.8214	0.8928	0.9285	0.7942

4. vit_large_patch16_224 with BW-FT
Results on 12 class validation set
Rank1	Rank5	Rank10	MAP
1	1	1	0.9914

As the results with VIT large are good on 12 class validation set- we choose this as our new backbone and an improvement over the previous model

##Improvement2: vit_large_patch16_224 with BW-FT
To further compare over larger test set, we evaluated on Market-1501 test set which has 750 classes.
The baseline results are:
Rank1	Rank5	Rank10	MAP
0.8266	0.89934	0.92428	0.761507

Improved results are
Rank1	Rank5	Rank10	MAP
0.96644	0.9872	0.99168	0.885

To further improve these results we propose 
##Improvement1 model: vit_large_patch16_384

Changes above baseline
1. Initial size of image given as input to improved model - 384 x 384
2. Number of patches = 384*384 / (16*16) = 24 
3. Dimension of each patch embedding- 1024
4. Tried data augumentation techniques like random horizontal flip, random vertical flip, colorjitter to increase the robustness of the model
5. Increased the dataset to total 825 classes (751 - market-trainset, 62 - our trainset, 12 - our valset)

This model is now capable of capturing more local information in its 1024-D vector. 
we evaluated on Market-1501 test set which has 750 classes
Improved results are
Rank1		Rank5		Rank10		MAP
0.977434	0.993171	0.994952	0.911582

Result screenshots are attached as JPG files in the folder
The zip folder contains the train, test, model, metrics and utils code for all three implementation. 
The model weights are submitted in the google drive folder with propoer naming conventions. 
1. BASELINE
2. Improvement1
3. Improvement2

We have performed various experiments like
1. With and without Blockwise - Finetuning
2. Various backbones replacing vit-base

Results, graphs and tables are also reported in the Report attached in the folder. The attached ipynb is the demo notebook. 


Contribution of Each team member:

Shivangi Bithel: 
1. Implementing the baseline
2. Methodological/ Design changes for improving any baseline method
(All the coding part)
3. Implementation Details, Tables, visualization, Ablation study and analysis in the Report

Sagar Sharma:
1. Report - Abstract, Introduction, Related work, Methodology, Dataset and Metrics, Conclusion and Future work, References 
2. Demo Notebook